print("Как вас зовут?")
Name = input()
print("Рады Вас видеть,", Name, "!")