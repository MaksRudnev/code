t = input("Введите текст")
print(t)
print(t)